﻿import { registrarUsuario, iniciarSesion, crearUsuario, escucharUsuarios, actualizarUsuario, eliminarUsuario } from './api.js';

document.addEventListener('DOMContentLoaded', () => {
    const loginContainer = document.getElementById('login-container');
    const registerContainer = document.getElementById('register-container');
    const panel = document.getElementById('panel');
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginMessage = document.getElementById('login-message');
    const registerMessage = document.getElementById('register-message');
    const sesionUsuario = document.getElementById('sesion-usuario');
    const btnLogout = document.getElementById('btn-logout');

    const form = document.getElementById('usuario-form');
    const inputId = document.getElementById('usuario-id');
    const inputUsuario = document.getElementById('usuario');
    const inputEmail = document.getElementById('email');
    const inputPassword = document.getElementById('password');
    const btnGuardar = document.getElementById('btn-guardar');
    const btnCancelar = document.getElementById('btn-cancelar');
    const mensaje = document.getElementById('mensaje');
    const tablaBody = document.getElementById('tabla-body');
    const sinDatos = document.getElementById('sin-datos');

    let tablaIniciada = false;

    function mostrarMensaje(div, texto, tipo) { div.textContent = texto; div.className = tipo; setTimeout(() => { div.textContent = ''; div.className = ''; }, 3000); }
    function formatearFecha(timestamp) { if (!timestamp) return '—'; return new Date(timestamp).toLocaleString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }

    showRegisterBtn.addEventListener('click', (e) => { e.preventDefault(); loginContainer.classList.add('hidden'); registerContainer.classList.remove('hidden'); });
    showLoginBtn.addEventListener('click', (e) => { e.preventDefault(); registerContainer.classList.add('hidden'); loginContainer.classList.remove('hidden'); });

    function abrirPanel(sesion) { loginContainer.classList.add('hidden'); registerContainer.classList.add('hidden'); panel.classList.remove('hidden'); sesionUsuario.textContent = ` ()`; if (!tablaIniciada) { iniciarTabla(); tablaIniciada = true; } }
    btnLogout.addEventListener('click', () => { panel.classList.add('hidden'); loginContainer.classList.remove('hidden'); loginForm.reset(); });

    registerForm.addEventListener('submit', async (e) => { e.preventDefault(); try { await registrarUsuario({ usuario: document.getElementById('register-name').value.trim(), email: document.getElementById('register-email').value.trim(), password: document.getElementById('register-password').value }); mostrarMensaje(registerMessage, 'Registro exitoso. Ya puedes iniciar sesión.', 'success'); registerForm.reset(); setTimeout(() => showLoginBtn.click(), 2000); } catch (error) { mostrarMensaje(registerMessage, error.message, 'error'); } });
    loginForm.addEventListener('submit', async (e) => { e.preventDefault(); try { const sesion = await iniciarSesion(document.getElementById('login-email').value.trim(), document.getElementById('login-password').value); abrirPanel(sesion); } catch (error) { mostrarMensaje(loginMessage, error.message, 'error'); } });

    function salirDeEdicion() { form.reset(); inputId.value = ''; btnGuardar.textContent = 'Guardar'; btnCancelar.classList.add('hidden'); }
    form.addEventListener('submit', async (e) => { e.preventDefault(); const datos = { usuario: inputUsuario.value.trim(), email: inputEmail.value.trim(), password: inputPassword.value }; try { if (inputId.value) { await actualizarUsuario(inputId.value, datos); mostrarMensaje(mensaje, 'Registro actualizado.', 'success'); } else { await crearUsuario(datos); mostrarMensaje(mensaje, 'Registro creado.', 'success'); } salirDeEdicion(); } catch (error) { mostrarMensaje(mensaje, 'Error al guardar: ' + error.message, 'error'); } });
    btnCancelar.addEventListener('click', salirDeEdicion);

    function iniciarTabla() {
        escucharUsuarios((lista) => {
            tablaBody.textContent = ''; sinDatos.classList.toggle('hidden', lista.length > 0);
            lista.forEach((registro) => {
                const fila = document.createElement('tr');
                const columnas = [registro.usuario, registro.email, registro.password, formatearFecha(registro.fechaCreacion)];
                columnas.forEach((valor) => { const celda = document.createElement('td'); celda.textContent = valor ?? ''; fila.appendChild(celda); });
                const acciones = document.createElement('td');
                const btnEditar = document.createElement('button'); btnEditar.type = 'button'; btnEditar.className = 'accion'; btnEditar.textContent = 'Editar';
                btnEditar.addEventListener('click', () => { inputId.value = registro.id; inputUsuario.value = registro.usuario ?? ''; inputEmail.value = registro.email ?? ''; inputPassword.value = registro.password ?? ''; btnGuardar.textContent = 'Actualizar'; btnCancelar.classList.remove('hidden'); inputUsuario.focus(); });
                const btnBorrar = document.createElement('button'); btnBorrar.type = 'button'; btnBorrar.className = 'accion peligro'; btnBorrar.textContent = 'Eliminar';
                btnBorrar.addEventListener('click', async () => { if (!confirm(¿Eliminar el registro ""?)) return; try { await eliminarUsuario(registro.id); mostrarMensaje(mensaje, 'Registro eliminado.', 'success'); if (inputId.value === registro.id) salirDeEdicion(); } catch (error) { mostrarMensaje(mensaje, 'Error al eliminar: ' + error.message, 'error'); } });
                acciones.append(btnEditar, btnBorrar); fila.appendChild(acciones); tablaBody.appendChild(fila);
            });
        });
    }
});
