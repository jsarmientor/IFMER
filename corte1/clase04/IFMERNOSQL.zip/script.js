import {
    registrarUsuario,
    iniciarSesion,
    crearUsuario,
    escucharUsuarios,
    actualizarUsuario,
    eliminarUsuario
} from './api.js';

document.addEventListener('DOMContentLoaded', () => {
    const loginContainer = document.getElementById('login-container');
    const registerContainer = document.getElementById('register-container');
    const panel = document.getElementById('panel');
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginMessage = document.getElementById('login-message');
    const registerMessage = document.getElementById('register-message');
    const sesionUsuario = document.getElementById('sesion-usuario');
    const btnLogout = document.getElementById('btn-logout');

    const form = document.getElementById('usuario-form');
    const inputId = document.getElementById('usuario-id');
    const inputUsuario = document.getElementById('usuario');
    const inputEmail = document.getElementById('email');
    const inputPassword = document.getElementById('password');
    const btnGuardar = document.getElementById('btn-guardar');
    const btnCancelar = document.getElementById('btn-cancelar');
    const mensaje = document.getElementById('mensaje');
    const tablaBody = document.getElementById('tabla-body');
    const sinDatos = document.getElementById('sin-datos');

    let tablaIniciada = false;

    function mostrarMensaje(div, texto, tipo) {
        div.textContent = texto;
        div.className = tipo;
        setTimeout(() => {
            div.textContent = '';
            div.className = '';
        }, 3000);
    }

    function formatearFecha(timestamp) {
        if (!timestamp) return '—';
        return new Date(timestamp).toLocaleString('es-ES', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Alternar vistas entre Login y Registro
    showRegisterBtn.addEventListener('click', (e) => {
        e.preventDefault();
        loginContainer.classList.add('hidden');
        registerContainer.classList.remove('hidden');
    });

    showLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        registerContainer.classList.add('hidden');
        loginContainer.classList.remove('hidden');
    });

    function abrirPanel(sesion) {
        loginContainer.classList.add('hidden');
        registerContainer.classList.add('hidden');
        panel.classList.remove('hidden');
        sesionUsuario.textContent = 