// CRUD y autenticación simple sobre Firebase Realtime Database (NoSQL)
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import {
    getDatabase,
    ref,
    push,
    set,
    update,
    remove,
    onValue,
    get,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-database.js";

const firebaseConfig = {
     apiKey: "AIzaSyA3GmMeLEhg8JtUWKsQZX9yPMsVmNEMioY",
  authDomain: "uriot-32f7d.firebaseapp.com",
  databaseURL: "https://uriot-32f7d.firebaseio.com",
  projectId: "uriot-32f7d",
  storageBucket: "uriot-32f7d.firebasestorage.app",
  messagingSenderId: "720901950215",
  appId: "1:720901950215:web:6b63c809e8b001dc6c53a2"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const usuariosRef = ref(db, "usuarios");

// Se filtra en el cliente para no depender de ".indexOn" en las reglas
async function buscarPorEmail(email) {
    const snapshot = await get(usuariosRef);
    if (!snapshot.exists()) return null;
    const encontrado = Object.entries(snapshot.val())
        .find(([, valores]) => valores.email === email);
    if (!encontrado) return null;
    return { id: encontrado[0], ...encontrado[1] };
}

// REGISTRO
export async function registrarUsuario({ usuario, email, password }) {
    if (await buscarPorEmail(email)) {
        throw new Error("Este correo ya está registrado.");
    }
    const nuevoRef = push(usuariosRef);
    await set(nuevoRef, { usuario, email, password, fechaCreacion: serverTimestamp() });
    return { id: nuevoRef.key, usuario, email };
}

// LOGIN
export async function iniciarSesion(email, password) {
    const encontrado = await buscarPorEmail(email);
    if (!encontrado || encontrado.password !== password) {
        throw new Error("Correo o contraseña incorrectos.");
    }
    return { id: encontrado.id, usuario: encontrado.usuario, email: encontrado.email };
}

// CREATE
export async function crearUsuario({ usuario, email, password }) {
    const nuevoRef = push(usuariosRef);
    await set(nuevoRef, { usuario, email, password, fechaCreacion: serverTimestamp() });
    return nuevoRef.key;
}

// READ: se dispara cada vez que cambian los datos en el servidor
export function escucharUsuarios(callback) {
    onValue(usuariosRef, (snapshot) => {
        const datos = snapshot.val() || {};
        const lista = Object.entries(datos).map(([id, valores]) => ({ id, ...valores }));
        callback(lista);
    });
}

// UPDATE
export async function actualizarUsuario(id, { usuario, email, password }) {
    await update(ref(db, 