<?php
header('Content-Type: application/json');

// 1. Configuración de Conexión a Base de Datos
$host = 'localhost';
$dbname = 'sistema_login';
$user = 'root'; // Ajustar según servidor
$pass = '';     // Ajustar según servidor

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => "Error de conexión a BD"]);
    exit;
}

// 2. Procesamiento de Solicitudes (Create & Read)
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // CRUD: CREATE (Registro)
    if ($action === 'register') {
        $nombre = $_POST['nombre'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($nombre) || empty($email) || empty($password)) {
            echo json_encode(["success" => false, "error" => "Todos los campos son obligatorios"]);
            exit;
        }

        // Hash de contraseña por seguridad
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$nombre, $email, $hashed_password]);
            echo json_encode(["success" => true]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                echo json_encode(["success" => false, "error" => "El correo ya está registrado"]);
            } else {
                echo json_encode(["success" => false, "error" => "Error al registrar usuario"]);
            }
        }
    } 
    
    // CRUD: READ (Login)
    elseif ($action === 'login') {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            echo json_encode(["success" => false, "error" => "Correo y contraseña son obligatorios"]);
            exit;
        }

        $stmt = $pdo->prepare("SELECT id, nombre, password FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            echo json_encode([
                "success" => true, 
                "user" => [
                    "id" => $user['id'],
                    "nombre" => $user['nombre']
                ]
            ]);
        } else {
            echo json_encode(["success" => false, "error" => "Credenciales incorrectas"]);
        }
    }
}
?>