document.addEventListener('DOMContentLoaded', () => {
    const loginContainer = document.getElementById('login-container');
    const registerContainer = document.getElementById('register-container');
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    // Alternar vistas
    showRegisterBtn.addEventListener('click', (e) => {
        e.preventDefault();
        loginContainer.classList.add('hidden');
        registerContainer.classList.remove('hidden');
    });

    showLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        registerContainer.classList.add('hidden');
        loginContainer.classList.remove('hidden');
    });

    // Envío de Registro (Método POST)
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const nombre = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const messageDiv = document.getElementById('register-message');

        try {
            const response = await fetch('api.php?action=register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ nombre, email, password })
            });
            const data = await response.json();
            
            if(data.success) {
                messageDiv.textContent = 'Registro exitoso. Ya puedes iniciar sesión.';
                messageDiv.className = 'success';
                registerForm.reset();
            } else {
                messageDiv.textContent = data.error || 'Error en el registro.';
                messageDiv.className = 'error';
            }
        } catch (error) {
            messageDiv.textContent = 'Error de conexión.';
            messageDiv.className = 'error';
        }
    });

    // Envío de Login (Método POST)
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const messageDiv = document.getElementById('login-message');

        try {
            const response = await fetch('api.php?action=login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ email, password })
            });
            const data = await response.json();
            
            if(data.success) {
                messageDiv.textContent = '¡Bienvenido ' + data.user.nombre + '!';
                messageDiv.className = 'success';
            } else {
                messageDiv.textContent = data.error || 'Credenciales incorrectas.';
                messageDiv.className = 'error';
            }
        } catch (error) {
            messageDiv.textContent = 'Error de conexión.';
            messageDiv.className = 'error';
        }
    });
});