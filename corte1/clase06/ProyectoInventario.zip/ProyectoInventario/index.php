<?php
require 'api/conexion.php';

// ---------- Busqueda ----------
$busqueda = $_POST['campo'] ?? '';
$where = "WHERE i.EstadoEquipo = 1";

if ($busqueda !== '') {
    $b = $mysqli->real_escape_string($busqueda);
    $where .= " AND (i.ActivoFijo LIKE '%$b%'
                  OR i.NombreEquipo LIKE '%$b%'
                  OR i.Marca LIKE '%$b%'
                  OR i.Serie LIKE '%$b%')";
}

$sql = "SELECT i.IdEquipo, i.ActivoFijo, i.Placa, i.NombreEquipo, i.Marca,
               i.Modelo, i.Serie, i.AnioFabricacion,
               s.Nombre  AS Servicio,
               a.Nombre  AS Area,
               cb.Nombre AS ClasifBiomedica,
               cr.Codigo AS Riesgo,
               f.Nombre  AS FrecuenciaMpp
        FROM inventario i
        JOIN servicios s          ON s.IdServicio = i.IdServicio
        LEFT JOIN areas a         ON a.IdArea = i.IdArea
        JOIN clasif_biomedica cb  ON cb.IdClasifBiomedica = i.IdClasifBiomedica
        JOIN clasif_riesgo cr     ON cr.IdClasifRiesgo = i.IdClasifRiesgo
        LEFT JOIN frecuencias_mpp f ON f.IdFrecuenciaMpp = i.IdFrecuenciaMpp
        $where
        ORDER BY i.NombreEquipo";
$resultado = $mysqli->query($sql);

$servicios = $mysqli->query("SELECT IdServicio, Nombre FROM servicios ORDER BY Nombre");
$areas     = $mysqli->query("SELECT IdArea, Nombre FROM areas ORDER BY Nombre");
$biomed    = $mysqli->query("SELECT IdClasifBiomedica, Nombre FROM clasif_biomedica ORDER BY Nombre");
$riesgos   = $mysqli->query("SELECT IdClasifRiesgo, Codigo, Descripcion FROM clasif_riesgo ORDER BY IdClasifRiesgo");
$tecno     = $mysqli->query("SELECT IdTecnologia, Nombre FROM tecnologias ORDER BY Nombre");
$frecs     = $mysqli->query("SELECT IdFrecuenciaMpp, Nombre FROM frecuencias_mpp ORDER BY MesesIntervalo");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inventario de Equipos Biomédicos</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="jumbotron jumbotron-fluid py-4 mb-4" style="background:#941100;color:#fff;">
  <div class="container">
    <h1 class="display-5">Inventario de Equipos Biomédicos</h1>
    <p class="lead mb-0">Hospital Universitario Nivel III — Informática Médica IFMER 2026-II</p>
  </div>
</div>

<div class="container">

<h3 class="mb-3">Registrar equipo</h3>
<form method="POST" action="api/guardar.php">

  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="ActivoFijo">Activo fijo *</label>
      <input type="text" class="form-control" name="ActivoFijo" id="ActivoFijo" maxlength="15" required>
    </div>
    <div class="form-group col-md-3">
      <label for="Placa">Placa nueva</label>
      <input type="text" class="form-control" name="Placa" id="Placa" maxlength="15">
    </div>
    <div class="form-group col-md-6">
      <label for="NombreEquipo">Nombre del equipo *</label>
      <input type="text" class="form-control" name="NombreEquipo" id="NombreEquipo" maxlength="80" required>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="Marca">Marca *</label>
      <input type="text" class="form-control" name="Marca" id="Marca" maxlength="60" required>
    </div>
    <div class="form-group col-md-3">
      <label for="Modelo">Modelo</label>
      <input type="text" class="form-control" name="Modelo" id="Modelo" maxlength="40">
    </div>
    <div class="form-group col-md-3">
      <label for="Serie">Serie</label>
      <input type="text" class="form-control" name="Serie" id="Serie" maxlength="40">
    </div>
    <div class="form-group col-md-3">
      <label for="AnioFabricacion">Año de fabricación</label>
      <input type="number" class="form-control" name="AnioFabricacion" id="AnioFabricacion" min="1950" max="2100" placeholder="2013">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="IdServicio">Servicio *</label>
      <select name="IdServicio" id="IdServicio" class="form-control" required>
        <option value="">Seleccione…</option>
        <?php while ($s = $servicios->fetch_assoc()) { ?>
          <option value="<?php echo $s['IdServicio']; ?>"><?php echo $s['Nombre']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="IdArea">Área</label>
      <select name="IdArea" id="IdArea" class="form-control">
        <option value="">Seleccione…</option>
        <?php while ($a = $areas->fetch_assoc()) { ?>
          <option value="<?php echo $a['IdArea']; ?>"><?php echo $a['Nombre']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="IdClasifBiomedica">Clasificación biomédica *</label>
      <select name="IdClasifBiomedica" id="IdClasifBiomedica" class="form-control" required>
        <option value="">Seleccione…</option>
        <?php while ($c = $biomed->fetch_assoc()) { ?>
          <option value="<?php echo $c['IdClasifBiomedica']; ?>"><?php echo $c['Nombre']; ?></option>
        <?php } ?>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-3">
      <label for="IdClasifRiesgo">Riesgo (INVIMA) *</label>
      <select name="IdClasifRiesgo" id="IdClasifRiesgo" class="form-control" required>
        <option value="">Seleccione…</option>
        <?php while ($r = $riesgos->fetch_assoc()) { ?>
          <option value="<?php echo $r['IdClasifRiesgo']; ?>"><?php echo $r['Codigo'] . ' — ' . $r['Descripcion']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="IdTecnologia">Tecnología predominante</label>
      <select name="IdTecnologia" id="IdTecnologia" class="form-control">
        <option value="">Seleccione…</option>
        <?php while ($t = $tecno->fetch_assoc()) { ?>
          <option value="<?php echo $t['IdTecnologia']; ?>"><?php echo $t['Nombre']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="IdFrecuenciaMpp">Frecuencia de MPP</label>
      <select name="IdFrecuenciaMpp" id="IdFrecuenciaMpp" class="form-control">
        <option value="">Seleccione…</option>
        <?php while ($f = $frecs->fetch_assoc()) { ?>
          <option value="<?php echo $f['IdFrecuenciaMpp']; ?>"><?php echo $f['Nombre']; ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="FuenteAlimentacion">Fuente de alimentación</label>
      <select name="FuenteAlimentacion" id="FuenteAlimentacion" class="form-control">
        <option value="">Seleccione…</option>
        <option value="Electrica">Eléctrica</option>
        <option value="Bateria">Batería</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="VoltajeValor">Voltaje</label>
      <input type="number" class="form-control" name="VoltajeValor" id="VoltajeValor" placeholder="110">
    </div>
    <div class="form-group col-md-2">
      <label for="VoltajeTipo">Tipo</label>
      <select name="VoltajeTipo" id="VoltajeTipo" class="form-control">
        <option value="">—</option><option value="VAC">VAC</option><option value="VDC">VDC</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="CorrienteValor">Corriente</label>
      <input type="number" step="0.001" class="form-control" name="CorrienteValor" id="CorrienteValor">
    </div>
    <div class="form-group col-md-2">
      <label for="CorrienteUnidad">Unidad</label>
      <select name="CorrienteUnidad" id="CorrienteUnidad" class="form-control">
        <option value="">—</option><option value="A">A</option><option value="mA">mA</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="PotenciaW">Potencia (W)</label>
      <input type="number" class="form-control" name="PotenciaW" id="PotenciaW">
    </div>
    <div class="form-group col-md-2">
      <label for="PesoKg">Peso (kg)</label>
      <input type="number" step="0.001" class="form-control" name="PesoKg" id="PesoKg">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-3">
      <label>¿Maneja software?</label>
      <select name="ManejaSoftware" class="form-control"><option value="0">No</option><option value="1">Sí</option></select>
    </div>
    <div class="form-group col-md-3">
      <label>¿Requiere calibración?</label>
      <select name="RequiereCalibracion" class="form-control"><option value="0">No</option><option value="1">Sí</option></select>
    </div>
    <div class="form-group col-md-6">
      <label for="Accesorios">Accesorios</label>
      <input type="text" class="form-control" name="Accesorios" id="Accesorios" placeholder="Cable AC, Cable ECG, Palas">
    </div>
  </div>

  <button type="submit" class="btn btn-danger mb-4">Guardar equipo</button>
</form>

<hr>
<h3 class="mb-3">Consultar inventario</h3>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="form-inline mb-3">
  <input type="text" class="form-control mr-2" id="campo" name="campo"
         placeholder="Activo, nombre, marca o serie"
         value="<?php echo htmlspecialchars($busqueda); ?>">
  <input type="submit" value="Buscar" class="btn btn-info mr-2">
  <a href="index.php" class="btn btn-secondary">Limpiar</a>
</form>

<div class="table-responsive">
  <table class="table table-striped table-sm">
    <thead class="thead-dark">
      <tr>
        <th>Activo</th><th>Equipo</th><th>Marca</th><th>Modelo</th>
        <th>Serie</th><th>Año</th><th>Servicio</th><th>Área</th>
        <th>Clasificación</th><th>Riesgo</th><th>MPP</th><th colspan="2">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $resultado->fetch_assoc()) { ?>
        <tr>
          <td><?php echo $row['ActivoFijo']; ?></td>
          <td><?php echo $row['NombreEquipo']; ?></td>
          <td><?php echo $row['Marca']; ?></td>
          <td><?php echo $row['Modelo'] ?? '—'; ?></td>
          <td><?php echo $row['Serie'] ?? '—'; ?></td>
          <td><?php echo $row['AnioFabricacion'] ?? '—'; ?></td>
          <td><?php echo $row['Servicio']; ?></td>
          <td><?php echo $row['Area'] ?? '—'; ?></td>
          <td><?php echo $row['ClasifBiomedica']; ?></td>
          <td><span class="badge badge-warning"><?php echo $row['Riesgo']; ?></span></td>
          <td><?php echo $row['FrecuenciaMpp'] ?? '—'; ?></td>
          <td><a class="btn btn-sm btn-primary" href="modificar.php?id=<?php echo $row['IdEquipo']; ?>">Editar</a></td>
          <td><a class="btn btn-sm btn-danger" href="#"
                 data-href="api/eliminar.php?id=<?php echo $row['IdEquipo']; ?>"
                 data-toggle="modal" data-target="#confirm-delete">Dar de baja</a></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</div>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Dar de baja el equipo</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        ¿Confirma dar de baja este equipo? El registro <b>no se borra</b>: queda inactivo
        para conservar la trazabilidad del inventario.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <a class="btn btn-danger btn-ok">Confirmar</a>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script>
  $('#confirm-delete').on('show.bs.modal', function (e) {
    $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
  });
</script>

</body>
</html>
