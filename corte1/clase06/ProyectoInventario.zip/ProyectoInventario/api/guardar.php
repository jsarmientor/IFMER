<?php
// api/guardar.php
require 'conexion.php';

$campos = ['ActivoFijo','Placa','NombreEquipo','Marca','Modelo','Serie','AnioFabricacion',
           'IdServicio','IdArea','IdClasifBiomedica','IdClasifRiesgo','IdTecnologia',
           'IdFrecuenciaMpp','FuenteAlimentacion','VoltajeValor','VoltajeTipo',
           'CorrienteValor','CorrienteUnidad','PotenciaW','PesoKg',
           'ManejaSoftware','RequiereCalibracion','Accesorios'];

$datos = [];
foreach ($campos as $c) {
    $v = $_POST[$c] ?? '';
    $datos[$c] = ($v === '') ? null : $v;
}

$errores = [];
if (empty($datos['ActivoFijo']))        $errores[] = 'El activo fijo es obligatorio.';
if (empty($datos['NombreEquipo']))      $errores[] = 'El nombre del equipo es obligatorio.';
if (empty($datos['Marca']))             $errores[] = 'La marca es obligatoria.';
if (empty($datos['IdServicio']))        $errores[] = 'Debe seleccionar el servicio.';
if (empty($datos['IdClasifBiomedica'])) $errores[] = 'Debe seleccionar la clasificacion biomedica.';
if (empty($datos['IdClasifRiesgo']))    $errores[] = 'Debe seleccionar la clasificacion de riesgo.';

if (!empty($datos['AnioFabricacion'])) {
    $anio = (int)$datos['AnioFabricacion'];
    if ($anio < 1950 || $anio > (int)date('Y')) {
        $errores[] = 'El anio de fabricacion debe estar entre 1950 y ' . date('Y') . '.';
    }
}

$guardado = false;
$mensajeError = '';

if (empty($errores)) {
    $cols   = implode(', ', $campos);
    $marcas = implode(', ', array_fill(0, count($campos), '?'));
    $tipos  = str_repeat('s', count($campos));

    // En PHP 8, mysqli LANZA EXCEPCIONES: por eso va dentro de try/catch.
    try {
        $stmt = $mysqli->prepare("INSERT INTO inventario ($cols) VALUES ($marcas)");
        $stmt->bind_param($tipos, ...array_values($datos));
        $stmt->execute();
        $stmt->close();
        $guardado = true;
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            $mensajeError = 'Ya existe un equipo con ese numero de activo fijo.';
        } elseif ($e->getCode() == 1452) {
            $mensajeError = 'El servicio o la clasificacion seleccionada no existe en la tabla de dominio.';
        } else {
            $mensajeError = 'Error al guardar: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Guardar equipo</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5 text-center">
  <?php if ($guardado) { ?>
    <div class="alert alert-success"><h3>EQUIPO REGISTRADO</h3></div>
  <?php } else { ?>
    <div class="alert alert-danger">
      <h3>NO SE PUDO REGISTRAR</h3>
      <ul class="list-unstyled mb-0">
        <?php foreach ($errores as $e) { echo "<li>$e</li>"; } ?>
        <?php if ($mensajeError) { echo "<li>$mensajeError</li>"; } ?>
      </ul>
    </div>
  <?php } ?>
  <a href="../index.php" class="btn btn-primary">Regresar</a>
</div>
</body>
</html>
