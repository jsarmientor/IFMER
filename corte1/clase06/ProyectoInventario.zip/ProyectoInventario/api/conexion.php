<?php
// api/conexion.php
$mysqli = new mysqli('localhost', 'root', '', 'inventarioequipos');

if ($mysqli->connect_error) {
    die('Error en la conexion: ' . $mysqli->connect_error);
}

$mysqli->set_charset('utf8mb4');
