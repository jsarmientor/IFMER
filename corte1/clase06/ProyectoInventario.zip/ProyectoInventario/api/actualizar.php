<?php
// api/actualizar.php
require 'conexion.php';

$id = (int)($_GET['id'] ?? 0);

$campos = ['ActivoFijo','Placa','NombreEquipo','Marca','Modelo','Serie',
           'AnioFabricacion','IdServicio','IdClasifBiomedica','IdClasifRiesgo'];

$datos = [];
foreach ($campos as $c) {
    $v = $_POST['m' . $c] ?? '';
    $datos[$c] = ($v === '') ? null : $v;
}

$sets    = implode(' = ?, ', $campos) . ' = ?';
$tipos   = str_repeat('s', count($campos)) . 'i';
$valores = array_values($datos);
$valores[] = $id;

$ok = false; $filas = 0; $mensajeError = '';

try {
    $stmt = $mysqli->prepare("UPDATE inventario SET $sets WHERE IdEquipo = ?");
    $stmt->bind_param($tipos, ...$valores);
    $stmt->execute();
    $filas = $stmt->affected_rows;
    $stmt->close();
    $ok = true;
} catch (mysqli_sql_exception $e) {
    $mensajeError = ($e->getCode() == 1062)
        ? 'Ya existe otro equipo con ese numero de activo fijo.'
        : 'Error al actualizar: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Actualizar</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5 text-center">
  <?php if ($ok) { ?>
    <div class="alert alert-success">
      <h3>REGISTRO MODIFICADO</h3>
      <p class="mb-0">Filas afectadas: <?php echo $filas; ?></p>
    </div>
  <?php } else { ?>
    <div class="alert alert-danger"><h3>ERROR AL MODIFICAR</h3><p class="mb-0"><?php echo $mensajeError; ?></p></div>
  <?php } ?>
  <a href="../index.php" class="btn btn-primary">Regresar</a>
</div>
</body>
</html>
