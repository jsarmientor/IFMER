<?php
// api/eliminar.php
require 'conexion.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $mysqli->prepare("UPDATE inventario SET EstadoEquipo = 0 WHERE IdEquipo = ?");
$stmt->bind_param('i', $id);
$ok = $stmt->execute();
$filas = $stmt->affected_rows;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dar de baja</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5 text-center">
  <?php if ($ok && $filas > 0) { ?>
    <div class="alert alert-warning"><h3>EQUIPO DADO DE BAJA</h3>
      <p class="mb-0">El registro sigue en la base de datos con <code>EstadoEquipo = 0</code>.</p>
    </div>
  <?php } else { ?>
    <div class="alert alert-danger"><h3>NO SE PUDO DAR DE BAJA</h3></div>
  <?php } ?>
  <a href="../index.php" class="btn btn-primary">Regresar</a>
</div>
</body>
</html>
