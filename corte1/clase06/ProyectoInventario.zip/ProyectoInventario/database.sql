-- =========================================================
--  IFMER 2026-II | Clase 06
--  Inventario de equipos biomedicos - Hospital Universitario Nivel III
--  Fuente: BD.xlsx, hoja "Listado Equipos"
-- =========================================================
CREATE DATABASE IF NOT EXISTS inventarioequipos
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventarioequipos;

-- Sin esta linea, las tildes y la N con virgulilla se guardan mal
SET NAMES utf8mb4;

-- ---------------- TABLAS DE DOMINIO ----------------
CREATE TABLE IF NOT EXISTS servicios (
  IdServicio INT AUTO_INCREMENT PRIMARY KEY,
  Nombre     VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT IGNORE INTO servicios (Nombre) VALUES
('SALAS DE CIRUGIA'), ('UCI 2 PISO'), ('UCI 4 PISO'), ('UCI CORONARIA'),
('LABORATORIO CLINICO'), ('RADIOLOGIA'), ('URGENCIAS'), ('FISIOTERAPIA'),
('TERAPIA FISICA'), ('DEPARTAMENTO ENFERMERIA'), ('HOSPITALIZACION 3 SUR'),
('HOSPITALIZACION 6 SUR'), ('HOSPITALIZACION 7 SUR'), ('CONSULTA EXTERNA');

CREATE TABLE IF NOT EXISTS areas (
  IdArea     INT AUTO_INCREMENT PRIMARY KEY,
  IdServicio INT NOT NULL,
  Nombre     VARCHAR(60) NOT NULL,
  CONSTRAINT fk_area_servicio FOREIGN KEY (IdServicio) REFERENCES servicios(IdServicio)
) ENGINE=InnoDB;

INSERT IGNORE INTO areas (IdServicio, Nombre) VALUES
(1,'SALA'), (1,'ESTERILIZACION'), (2,'CUBICULO'), (3,'CUBICULO'),
(4,'CARRO DE PARO'), (5,'CENTRIFUGACION'), (5,'COAGULACION'),
(5,'UNIDAD TRANSFUCIONAL'), (6,'ECOGRAFIAS'), (6,'RADIOLOGIA'),
(7,'CONSULTORIO'), (7,'CONSULTORIO Nº 2'), (8,'CONSULTORIO Nº 4'), (11,'HABITACION');

CREATE TABLE IF NOT EXISTS clasif_biomedica (
  IdClasifBiomedica INT AUTO_INCREMENT PRIMARY KEY,
  Nombre            VARCHAR(40) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT IGNORE INTO clasif_biomedica (Nombre) VALUES
('Diagnostico'), ('Tratamiento'), ('Soporte de Vida'),
('Laboratorio Clinico'), ('Apoyo y Tratamiento'), ('Prevencion'), ('Rehabilitacion');

CREATE TABLE IF NOT EXISTS clasif_riesgo (
  IdClasifRiesgo INT AUTO_INCREMENT PRIMARY KEY,
  Codigo         VARCHAR(4)  NOT NULL UNIQUE,
  Descripcion    VARCHAR(80) NOT NULL
) ENGINE=InnoDB;

-- Clasificacion INVIMA. Nota: BD.xlsx solo trae I, IIA y IIB,
-- pero el dominio normativo incluye III: se registra completo.
INSERT IGNORE INTO clasif_riesgo (Codigo, Descripcion) VALUES
('I',   'Riesgo bajo'),
('IIA', 'Riesgo moderado'),
('IIB', 'Riesgo alto'),
('III', 'Riesgo muy alto');

CREATE TABLE IF NOT EXISTS clasif_electrica (
  IdClasifElectrica INT AUTO_INCREMENT PRIMARY KEY,
  Codigo            VARCHAR(15) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT IGNORE INTO clasif_electrica (Codigo) VALUES
('B Clase I'), ('B Clase II'), ('BF Clase I'), ('BF Clase II'),
('CF Clase I'), ('CF Clase II'), ('Clase III');

CREATE TABLE IF NOT EXISTS tecnologias (
  IdTecnologia INT AUTO_INCREMENT PRIMARY KEY,
  Nombre       VARCHAR(30) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT IGNORE INTO tecnologias (Nombre) VALUES
('Electrica'), ('Electronica'), ('Mecanica'),
('Electromecanica'), ('Electroneumatica'), ('Electrohidraulica');

CREATE TABLE IF NOT EXISTS frecuencias_mpp (
  IdFrecuenciaMpp INT AUTO_INCREMENT PRIMARY KEY,
  Nombre          VARCHAR(20) NOT NULL UNIQUE,
  MesesIntervalo  TINYINT     NOT NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO frecuencias_mpp (Nombre, MesesIntervalo) VALUES
('Bimestral', 2), ('Trimestral', 3), ('Semestral', 6), ('Anual', 12);

-- ---------------- TABLA PRINCIPAL ----------------
CREATE TABLE IF NOT EXISTS inventario (
  IdEquipo               INT AUTO_INCREMENT PRIMARY KEY,

  -- Identificacion del equipo
  ActivoFijo             VARCHAR(15)  NOT NULL,
  Placa                  VARCHAR(15)  NULL,
  NombreEquipo           VARCHAR(80)  NOT NULL,
  Marca                  VARCHAR(60)  NOT NULL,
  Modelo                 VARCHAR(40)  NULL,
  Serie                  VARCHAR(40)  NULL,
  AnioFabricacion        YEAR         NULL,

  -- Localizacion
  IdServicio             INT          NOT NULL,
  IdArea                 INT          NULL,

  -- Caracteristicas electricas (columnas DIVIDIDAS)
  VoltajeValor           SMALLINT     NULL,
  VoltajeTipo            CHAR(3)      NULL,
  CorrienteValor         DECIMAL(7,3) NULL,
  CorrienteUnidad        CHAR(2)      NULL,
  PotenciaW              INT          NULL,
  FuenteAlimentacion     ENUM('Electrica','Bateria') NULL,
  CaracteristicasBateria VARCHAR(30)  NULL,

  -- Caracteristicas fisicas
  PesoKg                 DECIMAL(8,3) NULL,
  AltoMm                 INT          NULL,
  AnchoMm                INT          NULL,
  ProfundoMm             INT          NULL,

  -- Condiciones de operacion (rangos DIVIDIDOS)
  TempMinC               SMALLINT     NULL,
  TempMaxC               SMALLINT     NULL,
  HumMinPct              TINYINT      NULL,
  HumMaxPct              TINYINT      NULL,

  -- Clasificaciones (columnas NORMALIZADAS)
  IdClasifElectrica      INT          NULL,
  IdClasifBiomedica      INT          NOT NULL,
  IdClasifRiesgo         INT          NOT NULL,
  IdTecnologia           INT          NULL,
  IdFrecuenciaMpp        INT          NULL,

  -- Booleanos
  ManejaSoftware         TINYINT(1)   NULL,
  RequiereCalibracion    TINYINT(1)   NULL,

  -- Texto libre y trazabilidad
  Accesorios             TEXT         NULL,
  EstadoEquipo           TINYINT(1)   NOT NULL DEFAULT 1,
  FechaRegistro          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,

  -- Integridad
  CONSTRAINT uq_activo    UNIQUE (ActivoFijo),
  CONSTRAINT fk_inv_serv  FOREIGN KEY (IdServicio)        REFERENCES servicios(IdServicio),
  CONSTRAINT fk_inv_area  FOREIGN KEY (IdArea)            REFERENCES areas(IdArea),
  CONSTRAINT fk_inv_bio   FOREIGN KEY (IdClasifBiomedica) REFERENCES clasif_biomedica(IdClasifBiomedica),
  CONSTRAINT fk_inv_ries  FOREIGN KEY (IdClasifRiesgo)    REFERENCES clasif_riesgo(IdClasifRiesgo),
  CONSTRAINT fk_inv_elec  FOREIGN KEY (IdClasifElectrica) REFERENCES clasif_electrica(IdClasifElectrica),
  CONSTRAINT fk_inv_tec   FOREIGN KEY (IdTecnologia)      REFERENCES tecnologias(IdTecnologia),
  CONSTRAINT fk_inv_mpp   FOREIGN KEY (IdFrecuenciaMpp)   REFERENCES frecuencias_mpp(IdFrecuenciaMpp),
  CONSTRAINT ck_anio      CHECK (AnioFabricacion IS NULL OR AnioFabricacion BETWEEN 1950 AND 2100),
  CONSTRAINT ck_temp      CHECK (TempMinC IS NULL OR TempMaxC IS NULL OR TempMinC <= TempMaxC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_inv_nombre ON inventario (NombreEquipo);

-- ---------------- DATOS DE PRUEBA (tomados de BD.xlsx) ----------------
INSERT INTO inventario
(ActivoFijo, Placa, NombreEquipo, Marca, Modelo, Serie, AnioFabricacion,
 IdServicio, IdArea, VoltajeValor, VoltajeTipo, CorrienteValor, CorrienteUnidad,
 PotenciaW, FuenteAlimentacion, PesoKg, AltoMm, AnchoMm, ProfundoMm,
 TempMinC, TempMaxC, HumMinPct, HumMaxPct,
 IdClasifElectrica, IdClasifBiomedica, IdClasifRiesgo, IdTecnologia, IdFrecuenciaMpp,
 ManejaSoftware, RequiereCalibracion, Accesorios)
VALUES
('3393','E000355','AUTOCLAVE','ARAWELL',NULL,NULL,2006,
 1,2,380,'VAC',10.000,'A',3600,'Electrica',450.000,1000,1850,580,
 0,150,30,80, 2,3,3,5,2, 0,1,NULL),
('1146',NULL,'BASCULA ANALOGA','HEALTH O METER','233KG',NULL,2013,
 7,12,NULL,NULL,NULL,NULL,NULL,NULL,15.000,280,1470,560,
 0,58,30,60, NULL,1,1,3,2, 0,1,NULL),
('E000774',NULL,'AGITADOR DE PLAQUETAS','HELMER','PF151','1011960',2013,
 5,8,110,'VAC',NULL,NULL,NULL,'Electrica',NULL,NULL,NULL,NULL,
 NULL,NULL,30,60, NULL,4,1,1,3, 0,0,NULL);

-- ================= BONUS: criticidad y vista =================
CREATE TABLE IF NOT EXISTS criticidad (
  IdCriticidad   INT AUTO_INCREMENT PRIMARY KEY,
  IdEquipo       INT NOT NULL,
  FrecuenciaUso  TINYINT NOT NULL,
  FormaUso       TINYINT NOT NULL,
  ExactitudReq   TINYINT NOT NULL,
  ImportanciaEco TINYINT NOT NULL,
  -- Columna generada: MySQL la calcula sola, nadie la puede desincronizar
  PuntajeTotal   TINYINT AS (FrecuenciaUso + FormaUso + ExactitudReq + ImportanciaEco) STORED,
  CONSTRAINT fk_crit_equipo FOREIGN KEY (IdEquipo) REFERENCES inventario(IdEquipo),
  CONSTRAINT ck_rangos CHECK (
       FrecuenciaUso  BETWEEN 1 AND 5
   AND FormaUso       BETWEEN 1 AND 5
   AND ExactitudReq   BETWEEN 1 AND 5
   AND ImportanciaEco BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- Vista que traduce el puntaje al periodo de mantenimiento
CREATE OR REPLACE VIEW v_cronograma_mpp AS
SELECT i.IdEquipo, i.NombreEquipo, s.Nombre AS Servicio, c.PuntajeTotal,
       CASE
         WHEN c.PuntajeTotal BETWEEN 18 AND 20 THEN 'BIMESTRAL'
         WHEN c.PuntajeTotal BETWEEN 14 AND 17 THEN 'TRIMESTRAL'
         WHEN c.PuntajeTotal BETWEEN  9 AND 13 THEN 'SEMESTRAL'
         ELSE 'ANUAL'
       END AS PeriodoMpp
FROM criticidad c
JOIN inventario i ON i.IdEquipo = c.IdEquipo
JOIN servicios  s ON s.IdServicio = i.IdServicio;

-- Ejemplo: MONITOR MULTIPARAMETROS de la hoja MPP -> 5+5+5+4 = 19 -> BIMESTRAL
INSERT INTO criticidad (IdEquipo, FrecuenciaUso, FormaUso, ExactitudReq, ImportanciaEco)
VALUES (1, 5, 4, 4, 4);

SELECT * FROM v_cronograma_mpp;
