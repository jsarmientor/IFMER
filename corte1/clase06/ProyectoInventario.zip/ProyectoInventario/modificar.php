<?php
require 'api/conexion.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $mysqli->prepare("SELECT * FROM inventario WHERE IdEquipo = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    die('<div style="font-family:sans-serif;padding:2rem">Equipo no encontrado. <a href="index.php">Regresar</a></div>');
}

$servicios = $mysqli->query("SELECT IdServicio, Nombre FROM servicios ORDER BY Nombre");
$biomed    = $mysqli->query("SELECT IdClasifBiomedica, Nombre FROM clasif_biomedica ORDER BY Nombre");
$riesgos   = $mysqli->query("SELECT IdClasifRiesgo, Codigo FROM clasif_riesgo ORDER BY IdClasifRiesgo");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Modificar equipo</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h2>Modificar equipo #<?php echo $row['IdEquipo']; ?></h2>

  <form method="POST" action="api/actualizar.php?id=<?php echo $row['IdEquipo']; ?>">

    <div class="form-row">
      <div class="form-group col-md-3">
        <label>Activo fijo *</label>
        <input type="text" class="form-control" name="mActivoFijo" required
               value="<?php echo htmlspecialchars($row['ActivoFijo']); ?>">
      </div>
      <div class="form-group col-md-3">
        <label>Placa</label>
        <input type="text" class="form-control" name="mPlaca"
               value="<?php echo htmlspecialchars($row['Placa'] ?? ''); ?>">
      </div>
      <div class="form-group col-md-6">
        <label>Nombre del equipo *</label>
        <input type="text" class="form-control" name="mNombreEquipo" required
               value="<?php echo htmlspecialchars($row['NombreEquipo']); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group col-md-3">
        <label>Marca *</label>
        <input type="text" class="form-control" name="mMarca" required
               value="<?php echo htmlspecialchars($row['Marca']); ?>">
      </div>
      <div class="form-group col-md-3">
        <label>Modelo</label>
        <input type="text" class="form-control" name="mModelo"
               value="<?php echo htmlspecialchars($row['Modelo'] ?? ''); ?>">
      </div>
      <div class="form-group col-md-3">
        <label>Serie</label>
        <input type="text" class="form-control" name="mSerie"
               value="<?php echo htmlspecialchars($row['Serie'] ?? ''); ?>">
      </div>
      <div class="form-group col-md-3">
        <label>Año de fabricación</label>
        <input type="number" class="form-control" name="mAnioFabricacion" min="1950" max="2100"
               value="<?php echo $row['AnioFabricacion']; ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group col-md-4">
        <label>Servicio *</label>
        <select name="mIdServicio" class="form-control" required>
          <?php while ($s = $servicios->fetch_assoc()) { ?>
            <option value="<?php echo $s['IdServicio']; ?>"
              <?php if ($row['IdServicio'] == $s['IdServicio']) echo 'selected'; ?>>
              <?php echo $s['Nombre']; ?>
            </option>
          <?php } ?>
        </select>
      </div>
      <div class="form-group col-md-4">
        <label>Clasificación biomédica *</label>
        <select name="mIdClasifBiomedica" class="form-control" required>
          <?php while ($c = $biomed->fetch_assoc()) { ?>
            <option value="<?php echo $c['IdClasifBiomedica']; ?>"
              <?php if ($row['IdClasifBiomedica'] == $c['IdClasifBiomedica']) echo 'selected'; ?>>
              <?php echo $c['Nombre']; ?>
            </option>
          <?php } ?>
        </select>
      </div>
      <div class="form-group col-md-4">
        <label>Riesgo *</label>
        <select name="mIdClasifRiesgo" class="form-control" required>
          <?php while ($r = $riesgos->fetch_assoc()) { ?>
            <option value="<?php echo $r['IdClasifRiesgo']; ?>"
              <?php if ($row['IdClasifRiesgo'] == $r['IdClasifRiesgo']) echo 'selected'; ?>>
              <?php echo $r['Codigo']; ?>
            </option>
          <?php } ?>
        </select>
      </div>
    </div>

    <button type="submit" class="btn btn-danger">Actualizar</button>
    <a href="index.php" class="btn btn-secondary">Regresar</a>
  </form>
</div>
</body>
</html>
